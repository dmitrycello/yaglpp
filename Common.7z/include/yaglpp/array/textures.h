#pragma once
#include <yaglpp/gladpp.h>
namespace gl {
} // namespace gl
