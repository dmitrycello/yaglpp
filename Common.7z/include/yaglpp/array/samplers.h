#pragma once
#include <yaglpp/gladpp.h>
namespace gl {
#ifdef YAGLPP_VERSION_3_3
#endif // #ifdef YAGLPP_VERSION_3_3
} // namespace gl
