#pragma once
#include <yaglpp/gladpp.h>
namespace gl {
#ifdef YAGLPP_VERSION_3_0
#endif // #ifdef YAGLPP_VERSION_3_0
} // namespace gl
