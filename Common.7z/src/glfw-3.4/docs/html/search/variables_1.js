var searchData=
[
  ['blue_0',['blue',['../struct_g_l_f_wgammaramp.html#acf0c836d0efe29c392fe8d1a1042744b',1,'GLFWgammaramp']]],
  ['bluebits_1',['blueBits',['../struct_g_l_f_wvidmode.html#af310977f58d2e3b188175b6e3d314047',1,'GLFWvidmode']]],
  ['buttons_2',['buttons',['../struct_g_l_f_wgamepadstate.html#a27e9896b51c65df15fba2c7139bfdb9a',1,'GLFWgamepadstate']]]
];
